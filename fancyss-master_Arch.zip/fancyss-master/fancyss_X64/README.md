# fancyss_X64 for koolshare OpenWRT/LEDE X64 with koolcenter
适用于koolshare OpenWRT/LEDE X64 带酷软的固件，由于该固件酷软下架了koolss插件，本项目将其收入。

#### 相关链接：
* koolshare OpenWRT/LEDE X64机型的科学上网离线包：[https://github.com/hq450/fancyss_history_package/tree/master/X64](https://github.com/hq450/fancyss_history_package/tree/master/X64)