{
"build_date":"2020-01-01_23:00:07",
"description":"科学上网",
"home_url":"Main_Ss_Content.asp",
"md5":"c010d6a751cc92d18e88772375611477",
"name":"shadowsocks",
"tar_url": "https://raw.githubusercontent.com/hq450/fancyss/master/fancyss_arm/shadowsocks.tar.gz", 
"title":"科学上网",
"version":"4.2.2"
}
