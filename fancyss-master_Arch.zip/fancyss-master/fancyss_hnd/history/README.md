# fancyss_hnd - 科学上网离线安装包
离线包下载请前往：[https://github.com/hq450/fancyss_history_package/tree/master/fancyss_hnd](https://github.com/hq450/fancyss_history_package/tree/master/fancyss_hnd)