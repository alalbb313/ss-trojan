{
"build_date":"2020-12-12_23:05:49",
"description":"科学上网",
"home_url":"Module_shadowsocks.asp",
"md5":"1c3882c7928f35773f4cd698173e1c5c",
"name":"shadowsocks",
"tar_url": "https://raw.githubusercontent.com/hq450/fancyss/master/fancyss_hnd/shadowsocks.tar.gz", 
"title":"科学上网",
"version":"1.9.2"
}
