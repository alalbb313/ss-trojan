{
"build_date":"2019-12-10_11:56:03",
"description":"科学上网",
"home_url":"Module_shadowsocks.asp",
"md5":"c265a40af5c0670f406b51191e622357",
"name":"shadowsocks",
"tar_url": "https://raw.githubusercontent.com/hq450/fancyss/master/fancyss_arm384/shadowsocks.tar.gz", 
"title":"科学上网",
"version":"1.0.4"
}
